while [[ true ]]; do
  lua ./api/api.out
done
